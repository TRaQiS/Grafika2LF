import java.awt.image.BufferedImage;
import java.io.*;
import java.awt.*;
import java.util.Scanner;
import javax.swing.*;
import javax.imageio.*;


public class GrayScale {
    BufferedImage image;
    int width;
    int height;

    public GrayScale(int x, int y, int z, String filePath, String nazwa) {
        try {
            File input = new File(filePath + ".jpg");
            image = ImageIO.read(input);
            width = image.getWidth();
            height = image.getHeight();

            for (int i = 0; i < height; i++) {
                for (int j = 0; j < width; j++) {
                    Color c = new Color(image.getRGB(j, i));
                    int r = (int) (c.getRed());
                    int g = (int) (c.getGreen());
                    int b = (int) (c.getBlue());

//                    int r = (int)(c.getRed() * 0.299);
//                    int g = (int)(c.getGreen() * 0.587);
//                    int b = (int)(c.getBlue() *0.114);

                    if (r + x >= 0 && r + x <= 255)
                        r -= x;
                    if (g + y >= 0 && g + y <= 255)
                        g -= y;
                    if (b + z >= 0 && b + z <= 255)
                        b -= z;



                    Color newColor = new Color(r, g, b);
                    image.setRGB(j, i, newColor.getRGB());
                }
            }

            File output = new File(filePath + nazwa + ".jpg");
            ImageIO.write(image, "jpg", output);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    public GrayScale(String filePath, String nazwa) {
        try {
            File input = new File(filePath + ".jpg");
            image = ImageIO.read(input);
            width = image.getWidth();
            height = image.getHeight();

            for (int i = 0; i < height; i++) {
                for (int j = 0; j < width; j++) {
                    Color c = new Color(image.getRGB(j, i));
                    int r = (int) (c.getRed());
                    int g = (int) (c.getGreen());
                    int b = (int) (c.getBlue());

                    r = 255 - r;
                    g = 255 - g;
                    b = 255 - b;

                    Color newColor = new Color(r, g, b);
                    image.setRGB(j, i, newColor.getRGB());
                }
            }

            File output = new File(filePath + nazwa + ".jpg");
            ImageIO.write(image, "jpg", output);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    public GrayScale(int dc, String filePath, String nazwa) {
        try {
            File input = new File(filePath + ".jpg");
            image = ImageIO.read(input);
            width = image.getWidth();
            height = image.getHeight();

            for (int i = 0; i < height; i++) {
                for (int j = 0; j < width; j++) {
                    Color c = new Color(image.getRGB(j, i));
                    int r = (int) (c.getRed());
                    int g = (int) (c.getGreen());
                    int b = (int) (c.getBlue());

                    int x = (127 / (127 - dc)) * (r - dc);
                    int y = (127 / (127 - dc)) * (g - dc);
                    int z = (127 / (127 - dc)) * (b - dc);

                    if (r + x >= 0 && r + x <= 255)
                        r += x;
                    if (g + y >= 0 && g + y <= 255)
                        g += y;
                    if (b + z >= 0 && b + z <= 255)
                        b += z;

                    Color newColor = new Color(r, g, b);
                    image.setRGB(j, i, newColor.getRGB());
                }
            }
            File output = new File(filePath + nazwa + ".jpg");
            ImageIO.write(image, "jpg", output);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }



    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        System.out.print("Plik: ");
        String path = sc.nextLine();
        System.out.println("Operacja:");
        System.out.println("""
                            1. Rozjasnienie
                            2. Przyciemnienie
                            3. Negatyw
                            4. Zmiana kontrastu
                            5. Histogram
                            6. Maska
                            /*/
                            """);
        int tryb = sc.nextInt();
        System.out.println("/*/");

        if (tryb == 1 || tryb == 2) {
            System.out.println("Wpisz wartość tranformacji od 0 do 255:");
            int radix = sc.nextInt();
            System.out.println("/*/");
            if (tryb == 1)
                new GrayScale(radix, radix, radix, path, "_rozjasniony");
            else
                new GrayScale((radix * (-1)), (radix * (-1)), (radix * (-1)), path, "_przyciemniony");
        } else if (tryb == 3)
            new GrayScale(path, "_negatyw");
        else if (tryb == 4) {
            System.out.println("Wpisz wartość zmieniania kontrastu C od -128 do 127:");
            int dc = sc.nextInt();
            new GrayScale(dc, path, "_zmienionyKontrast");
        } else if (tryb == 5) {
                Histogram hist = new Histogram();
                hist.wywolanie();
        }
        else if(tryb == 6){
            Maska mask = new Maska();
            mask.maskowanie();
        }
        else
            System.out.println("Niepoprawna operacja");
    }
}
